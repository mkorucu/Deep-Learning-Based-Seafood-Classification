# fish_classification > 2024-01-11 3:49pm
https://universe.roboflow.com/annproject-qlwcc/fish_classification-xnmwm

Provided by a Roboflow user
License: CC BY 4.0

